#!/usr/bin/env python3
import os
import sqlite3
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify

def create_app():
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        SECRET_KEY="change-this-secret",
        DATABASE=os.path.join(app.instance_path, "stencil.db"),
    )

    # Ensure instance folder exists (on many platforms this resolves to ./instance locally,
    # or /var/app-instance in certain deployments)
    try:
        os.makedirs(app.instance_path, exist_ok=True)
    except OSError:
        pass

    def get_db():
        conn = sqlite3.connect(app.config["DATABASE"], detect_types=sqlite3.PARSE_DECLTYPES)
        conn.row_factory = sqlite3.Row
        return conn

    def init_db():
        conn = get_db()
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS stencil_list (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fg TEXT, side TEXT, customer TEXT, stencil_no TEXT, rack_no TEXT, location TEXT,
                stencil_mils TEXT, stencil_mils_usl TEXT, stencil_mils_lsl TEXT, stencil_pr_no TEXT,
                date_received TEXT, stencil_validation_dt TEXT, stencil_revalidation_dt TEXT,
                tension_a TEXT, tension_b TEXT, tension_c TEXT, tension_d TEXT, tension_e TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS stencil_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                stencil_id INTEGER,
                changed_column TEXT,
                old_value TEXT,
                new_value TEXT,
                changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (stencil_id) REFERENCES stencil_list (id)
            );
        """)
        conn.commit()
        conn.close()

    @app.before_first_request
    def setup():
        init_db()

    # Helper: ensure uppercase for all non-empty fields
    def to_upper(data: dict):
        out = {}
        for k, v in data.items():
            if v is None:
                out[k] = None
            else:
                s = str(v).strip()
                out[k] = s.upper()
        return out

    # Fetch history for a given stencil_id
    def fetch_history(stencil_id):
        conn = get_db()
        hist = conn.execute(
            "SELECT changed_column, old_value, new_value, changed_at FROM stencil_history WHERE stencil_id=? ORDER BY changed_at DESC, id DESC",
            (stencil_id,)
        ).fetchall()
        conn.close()
        return hist

    # ROUTES
    @app.route("/")
    def home():
        conn = get_db()
        rows = conn.execute("""
            SELECT id, fg, side, customer, stencil_no, rack_no, location
            FROM stencil_list
            ORDER BY updated_at DESC, id DESC
        """).fetchall()
        conn.close()
        return render_template("home.html", rows=rows)

    @app.route("/received")
    def received():
        conn = get_db()
        rows = conn.execute("""
            SELECT *
            FROM stencil_list
            ORDER BY updated_at DESC, id DESC
        """).fetchall()
        conn.close()
        return render_template("received.html", rows=rows)

    @app.route("/history/<int:stencil_id>")
    def history(stencil_id):
        hist = fetch_history(stencil_id)
        payload = [dict(h) for h in hist]
        return jsonify(payload)

    @app.route("/add", methods=["POST"])
    def add():
        form = request.form.to_dict()
        data = to_upper(form)

        conn = get_db()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO stencil_list (
                fg, side, customer, stencil_no, rack_no, location,
                stencil_mils, stencil_mils_usl, stencil_mils_lsl, stencil_pr_no,
                date_received, stencil_validation_dt, stencil_revalidation_dt,
                tension_a, tension_b, tension_c, tension_d, tension_e
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            data.get("fg"), data.get("side"), data.get("customer"), data.get("stencil_no"),
            data.get("rack_no"), data.get("location"),
            data.get("stencil_mils"), data.get("stencil_mils_usl"), data.get("stencil_mils_lsl"),
            data.get("stencil_pr_no"),
            data.get("date_received"), data.get("stencil_validation_dt"), data.get("stencil_revalidation_dt"),
            data.get("tension_a"), data.get("tension_b"), data.get("tension_c"), data.get("tension_d"), data.get("tension_e")
        ))
        conn.commit()
        conn.close()
        flash("Record added.", "success")
        return redirect(request.referrer or url_for("home"))

    @app.route("/edit/<int:stencil_id>")
    def edit(stencil_id):
        conn = get_db()
        row = conn.execute("SELECT * FROM stencil_list WHERE id=?", (stencil_id,)).fetchone()
        conn.close()
        if not row:
            flash("Record not found.", "error")
            return redirect(url_for("home"))
        return render_template("edit.html", row=row)

    @app.route("/update/<int:stencil_id>", methods=["POST"])
    def update(stencil_id):
        new_data = to_upper(request.form.to_dict())

        conn = get_db()
        cur = conn.cursor()
        old = cur.execute("SELECT * FROM stencil_list WHERE id=?", (stencil_id,)).fetchone()
        if not old:
            conn.close()
            flash("Record not found.", "error")
            return redirect(url_for("home"))

        # Compare field by field and record history for changes
        fields = [
            "fg","side","customer","stencil_no","rack_no","location",
            "stencil_mils","stencil_mils_usl","stencil_mils_lsl","stencil_pr_no",
            "date_received","stencil_validation_dt","stencil_revalidation_dt",
            "tension_a","tension_b","tension_c","tension_d","tension_e"
        ]

        changes = []
        for f in fields:
            old_val = (old[f] if old[f] is not None else "")
            new_val = (new_data.get(f) or "")
            if str(old_val) != str(new_val):
                changes.append((stencil_id, f, str(old_val), str(new_val)))

        if changes:
            cur.executemany(
                "INSERT INTO stencil_history (stencil_id, changed_column, old_value, new_value) VALUES (?,?,?,?)",
                changes
            )
            # Apply update
            set_clause = ", ".join([f"{f}=?" for f in fields]) + ", updated_at=CURRENT_TIMESTAMP"
            values = [new_data.get(f) for f in fields]
            values.append(stencil_id)
            cur.execute(f"UPDATE stencil_list SET {set_clause} WHERE id=?", values)
            conn.commit()
            flash(f"Updated record {stencil_id} with {len(changes)} change(s).", "success")
        else:
            flash("No changes detected.", "info")

        conn.close()
        return redirect(url_for("received"))

    @app.route("/delete/<int:stencil_id>", methods=["POST"])
    def delete(stencil_id):
        conn = get_db()
        cur = conn.cursor()
        cur.execute("DELETE FROM stencil_list WHERE id=?", (stencil_id,))
        cur.execute("DELETE FROM stencil_history WHERE stencil_id=?", (stencil_id,))
        conn.commit()
        conn.close()
        flash("Record deleted.", "success")
        return redirect(request.referrer or url_for("home"))

    return app

app = create_app()

if __name__ == "__main__":
    # For local dev: python app.py
    app.run(host="127.0.0.1", port=5000, debug=True)
