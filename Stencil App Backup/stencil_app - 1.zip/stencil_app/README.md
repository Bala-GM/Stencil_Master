# Stencil Rack List (Flask, SQLite)

## Quick start
```bash
cd stencil_app
# (optional) python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install flask
python app.py
# Open http://127.0.0.1:5000
```

- The SQLite database is created in the **instance** folder at first run,
  using a dynamic, safe path: `app.instance_path/stencil.db`.
- All inputs are saved in **UPPERCASE** automatically on the server side.
- Every update writes to a `stencil_history` table. Click **History → Show**
  to see the change log on the right side of each row.
- Home Page shows: FG, SIDE, CUSTOMER, STENCIL NO, RACK NO, LOCATION.
- Received List shows all columns.
